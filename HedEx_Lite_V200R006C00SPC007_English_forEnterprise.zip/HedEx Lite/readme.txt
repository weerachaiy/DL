﻿**********************************************
HedEx Lite V200R006C00SPC007 11/15/2018
**********************************************

Read the following information before using HedEx Lite:

1. What is HedEx Lite?
HedEx Lite is software used to view, search for, and upgrade electronic documentation for Huawei products. It is the single-user edition of HedEx and occupies little disk space and little memory space.

2. What are the OSs supported by HedEx Lite?
(1) Windows 2003
(2) Windows XP Professional
(3) Windows Vista Home Basic, Ultimate, Business, and Enterprise editions
(4) Windows 7
(5) Microsoft Windows 8
(6) Microsoft Windows 8.1
(7) Microsoft Windows 10

3. What are the browsers supported by HedEx Lite?
(1) Microsoft Internet Explorer 8.0(Recommended)
(2) Microsoft Internet Explorer 9.0(Recommended)
(3) Microsoft Internet Explorer 10.0(Recommended)
(4) Microsoft Internet Explorer 11.0
(5) Mozilla Firefox 33.0(Recommended)
(6) Google Chrome 38.0(Recommended)
(7) Apple Safari 5.1.7(Recommended)
(8) Microsoft Edge 25.10586.0.0(Recommended)

4. How to use the Help?
After starting HedEx Lite, you can right-click the HedEx Lite tray icon and choose Help from the shortcut menu to view the online Help. If HedEx Lite cannot start, you can view the help.chm file contained in the HedEx Lite software package.

5. How to start HedEx Lite?
HedEx Lite does not require installation, double-click Startup.exe to start HedEx Lite (if the software package is compressed, decompress it).